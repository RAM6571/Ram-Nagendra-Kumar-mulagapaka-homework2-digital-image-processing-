import cv2
import numpy as np
import matplotlib.pyplot as plt
from scipy.fft import fftshift, fft2, ifft2
from scipy.ndimage import gaussian_filter

# Function to apply the Fourier Transform
def apply_fourier_transform(image):
    f = fft2(image)
    fshift = fftshift(f)
    magnitude_spectrum = 20 * np.log(np.abs(fshift))
    return fshift, magnitude_spectrum

# Function to apply Butterworth low-pass filter
def butterworth_low_pass_filter(shape, cutoff, order):
    P, Q = shape
    u = np.arange(P) - P // 2
    v = np.arange(Q) - Q // 2
    U, V = np.meshgrid(u, v)
    D = np.sqrt(U**2 + V**2)
    H = 1 / (1 + (D / cutoff)**(2 * order))
    return H

# Function to apply Gaussian low-pass filter
def gaussian_low_pass_filter(shape, sigma):
    P, Q = shape
    u = np.arange(P) - P // 2
    v = np.arange(Q) - Q // 2
    U, V = np.meshgrid(u, v)
    D = np.sqrt(U**2 + V**2)
    H = np.exp(-(D**2) / (2 * sigma**2))
    return H

# Function to apply the filter in the frequency domain and get the filtered image
def apply_filter_in_frequency_domain(fshift, filter_mask):
    fshift_filtered = fshift * filter_mask
    f_ishift = np.fft.ifftshift(fshift_filtered)
    img_back = np.abs(ifft2(f_ishift))
    return img_back

# Read image and convert to grayscale
image = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)
image = cv2.resize(image, (256, 256))  # Resize for simplicity

# Apply Fourier Transform
fshift, magnitude_spectrum = apply_fourier_transform(image)

# Butterworth Filter
butterworth_filter = butterworth_low_pass_filter(image.shape, cutoff=50, order=2)
image_butterworth_filtered = apply_filter_in_frequency_domain(fshift, butterworth_filter)

# Gaussian Filter
gaussian_filter_mask = gaussian_low_pass_filter(image.shape, sigma=50)
image_gaussian_filtered = apply_filter_in_frequency_domain(fshift, gaussian_filter_mask)

# Plotting results
plt.figure(figsize=(12, 12))

plt.subplot(2, 2, 1)
plt.imshow(image, cmap='gray')
plt.title('Original Image')

plt.subplot(2, 2, 2)
plt.imshow(magnitude_spectrum, cmap='gray')
plt.title('Fourier Transform')

plt.subplot(2, 2, 3)
plt.imshow(image_butterworth_filtered, cmap='gray')
plt.title('Butterworth Filtered Image')

plt.subplot(2, 2, 4)
plt.imshow(image_gaussian_filtered, cmap='gray')
plt.title('Gaussian Filtered Image')

plt.show()
