'''

A Kuwahara filter is a type of image processing filter used to reduce noise in digital images while preserving edges and textures. 
It is a non-local filter, meaning it takes into account the entire image when processing each pixel, rather than just neighboring pixels. 
This approach helps to effectively remove noise and preserve image details.

The Kuwahara filter works by dividing the image into small regions, called "windows,"
 and then applying a set of rules to each window to determine the output pixel value. 
 These rules are based on the local statistics of the window, such as the mean and variance of the pixel values. 
 The filter is particularly effective in removing Gaussian noise and salt-and-pepper noise from images.

'''

import cv2
import numpy as np
from scipy.signal import convolve2d

# Load the image


# Define the Kuwahara filter function
def Kuwahara(original, winsize):
    """
    Kuwahara filters an image using the Kuwahara filter
    
    Inputs:
    original      -->    image to be filtered
    windowSize    -->    size of the filter window: legal values are
                                                    5, 9, 13, ... = (4*k+1)
    
    Example
    filtered = Kuwahara(original,5);
    """
    # Check the time:
    #t1=time.time()

    #image = original.copy()
    # make sure original is a numpy array 
    image = original.astype(np.float64)
    # make sure window size is correct
    if winsize%4 != 1:
        raise Exception ("Invalid winsize %s: winsize must follow formula: w = 4*n+1." %winsize)

    #Build subwindows
    tmpAvgKerRow = np.hstack((np.ones((1,int((winsize-1)/2+1))),np.zeros((1,int((winsize-1)/2)))))
    tmpPadder = np.zeros((1,winsize))
    tmpavgker = np.tile(tmpAvgKerRow, (int((winsize-1)/2+1),1))
    tmpavgker = np.vstack((tmpavgker, np.tile(tmpPadder, (int((winsize-1)/2),1)) ))
    tmpavgker = tmpavgker/np.sum(tmpavgker)

    # tmpavgker is a 'north-west' subwindow (marked as 'a' above)
    # we build a vector of convolution kernels for computing average and
    # variance
    avgker = np.empty((4,winsize,winsize)) # make an empty vector of arrays
    avgker[0] = tmpavgker			# North-west (a)
    avgker[1] = np.fliplr(tmpavgker)	# North-east (b)
    avgker[2] = np.flipud(tmpavgker)	# South-west (c)
    avgker[3] = np.fliplr(avgker[2])	# South-east (d)
    
    # Create a pixel-by-pixel square of the image
    squaredImg = image**2
	
    # preallocate these arrays to make it apparently %15 faster
    avgs = np.zeros([4, image.shape[0],image.shape[1]])
    stddevs = avgs.copy()

    # Calculation of averages and variances on subwindows
    for k in range(4):
        avgs[k] = convolve2d(image, avgker[k],mode='same') 	    # mean on subwindow
        stddevs[k] = convolve2d(squaredImg, avgker[k],mode='same')  # mean of squares on subwindow
        stddevs[k] = stddevs[k]-avgs[k]**2 			    # variance on subwindow
	
    # Choice of index with minimum variance
    indices = np.argmin(stddevs,0) # returns index of subwindow with smallest variance

    # Building the filtered image (with nested for loops)
    filtered = np.zeros(original.shape)
    for row in range(original.shape[0]):
        for col in range(original.shape[1]):
            filtered[row,col] = avgs[indices[row,col], row,col]

    #filtered=filtered.astype(np.uint8)
    return filtered.astype(np.uint8)


# Apply the Kuwahara filter
img = cv2.imread('noisy_image.png', cv2.IMREAD_GRAYSCALE)
window_size = 5
filtered_img = Kuwahara(img, window_size)

# Display the original and filtered images
cv2.imshow('Original', img)
cv2.imshow('Filtered', filtered_img)
cv2.waitKey(0)
cv2.destroyAllWindows()